@echo off
cd /d "%~dp0"
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0CAPTURA_FACIAL.ps1"
attrib +h "%~dp0CAPTURA_FACIAL.ps1"
